import './App.css';
import Todo from './components/screens/Todo';

function App() {
  return <Todo />
}

export default App;
